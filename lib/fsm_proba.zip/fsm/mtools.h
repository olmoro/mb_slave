/*
  Файл   mtools.h
  Проект
  pcb: spn.55
*/

#ifndef _MTOOLS_H_
#define _MTOOLS_H_

#include "stdint.h"
#include "project_config.h"

#ifdef __cplusplus
extern "C"
{
#endif

    class MBoard;

    class MTools
    {
    public:
        MTools(MBoard *board);
        ~MTools();


        void    setState(unsigned short val);
        unsigned short getState();

    private:
    };

#ifdef __cplusplus
}
#endif

#endif // _MTOOLS_H_
