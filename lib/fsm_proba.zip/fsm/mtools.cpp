


#include "mtools.h"
#include "project_config.h"
#include "mboard.h"
//#include "mdispatcher.h"


MTools::MTools(MBoard * board) : Board(board) {}

MTools::~MTools() {}





// ==================================== Nvs read ====================================

// bool MTools::readNvsBool(const char * name, const char * key, const bool defaultValue)
// {
//   qPreferences->begin(name, true);                      // R-mode (second parameter has to be true).
//   bool val = qPreferences->getBool(key, defaultValue);
//   qPreferences->end();                                  // Close the Preferences
//   return val;  
// }

void MTools::setState(unsigned short val) { state = val; }
unsigned short MTools::getState() { return state; }
